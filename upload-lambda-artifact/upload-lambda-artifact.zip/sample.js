exports.sampleMsg = function() {
  console.log("This is a sample message");
}
